package ve.lm.onlinechinesechesscurriculumdesgino3cd.DaoTest;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.GameData;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.UserGameData;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.ServiceImplement.GameDataServiceImpl;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
public class GameDaoTest {

    @Autowired
    private GameDataServiceImpl gameDataServiceImpl;

    @Test
    @Transactional
    public void addGameData(){


        assertTrue(gameDataServiceImpl.addGameData(new GameData("mainGame",1L,2L,0,24,"noTie",1L)),"添加失败");
    }


}
