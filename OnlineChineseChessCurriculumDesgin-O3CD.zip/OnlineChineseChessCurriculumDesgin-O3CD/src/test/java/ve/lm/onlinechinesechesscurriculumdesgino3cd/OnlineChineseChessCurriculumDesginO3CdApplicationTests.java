package ve.lm.onlinechinesechesscurriculumdesgino3cd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineChineseChessCurriculumDesginO3CdApplicationTests {

    @Test
    void contextLoads() {
    }

}
