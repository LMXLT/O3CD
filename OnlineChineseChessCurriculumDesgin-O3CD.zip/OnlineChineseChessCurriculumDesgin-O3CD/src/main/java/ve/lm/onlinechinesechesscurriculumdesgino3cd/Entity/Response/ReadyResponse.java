package ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.Response;

public class ReadyResponse<String> extends Response<String>{

    private String owner;
    private Boolean isReady = false;

    public ReadyResponse(String description,String owner, Boolean isReady)
    {
        super(description);
        this.owner = owner;
        this.isReady = isReady;

    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public Boolean getIsReady() {
        return isReady;
    }

    public void setIsReady(Boolean ready) {
        isReady = ready;
    }


}
