package ve.lm.onlinechinesechesscurriculumdesgino3cd.ServiceImplement;

import org.springframework.stereotype.Service;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Dao.GameDataDao;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.GameData;


@Service
public class GameDataServiceImpl {

    private static final String jdbcUrl="jdbc:mysql://localhost:3306/onlinechinesechess?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";

    private static final String userName = "root";

    private static final String password = "LMX!101110001lt";


    private final GameDataDao gameDataDao = new GameDataDao(jdbcUrl, userName, password);

    public boolean addGameData(GameData gameData){

        return gameDataDao.addGameData(gameData);

    }

}
