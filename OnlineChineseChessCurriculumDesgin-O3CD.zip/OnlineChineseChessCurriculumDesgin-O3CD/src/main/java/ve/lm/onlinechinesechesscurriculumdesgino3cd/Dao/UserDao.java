package ve.lm.onlinechinesechesscurriculumdesgino3cd.Dao;

import org.springframework.http.server.DelegatingServerHttpResponse;
import org.springframework.stereotype.Repository;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.User;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.UserGameData;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.ServiceImplement.CounterServiceImpl;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDao {

    private String jdbcUrl;
    private String userName;
    private String password;

    public UserDao(String jdbcUrl, String userName, String password) {
        this.jdbcUrl = jdbcUrl;
        this.userName = userName;
        this.password = password;
    }

    public boolean registerUser(User user) {


        UserGameDataDao userGameDataDao = new UserGameDataDao(jdbcUrl,userName,password);
        if(!userGameDataDao.addUserGameDataAutomatically()){
            System.out.println("用户游戏数据新建失败！");

            Long back =User.getCounter()-1L;
            User.setCounter(back);
            return false;
        }



        String preSql = "alter table user auto_increment = ?";

        String sql01 = "INSERT INTO user (isManager, name, password, phoneNumber, email, userGameDataId) VALUES (?, ?, ?, ?, ?, ?)";
        String sql02 ="INSERT INTO onlinechinesechess.user (isManager, name, password, phoneNumber, userGameDataId) VALUES (?, ?, ?, ? ,?)";

        try {Connection conn = DriverManager.getConnection(jdbcUrl, userName, password);


            PreparedStatement pstmt,ppstmt;

            ppstmt = conn.prepareStatement(preSql);    // Mysql错误也自增
            ppstmt.setLong(1, User.getCounter()-1L);
            ppstmt.execute();


            if(!user.getEmail().isEmpty()) {
//                System.out.println("1");
                pstmt = conn.prepareStatement(sql01);
                pstmt.setString(1, "否");
                pstmt.setString(2, user.getName());
                pstmt.setString(3, user.getPassword());
                pstmt.setString(4, user.getPhoneNumber());
                pstmt.setString(5, user.getEmail());
                pstmt.setLong(6, UserGameData.getUniqueIdProduct());
            }
            else{
//                System.out.println("2");
                pstmt = conn.prepareStatement(sql02);
                pstmt.setString(1, "否");
                pstmt.setString(2, user.getName());
                pstmt.setString(3, user.getPassword());
                pstmt.setString(4, user.getPhoneNumber());
                pstmt.setLong(5, UserGameData.getUniqueIdProduct());
            }



            int affectedRows = pstmt.executeUpdate();
            if(affectedRows>0) {

                CounterServiceImpl.saveUserCounter(User.getCounter());
                UserGameData.setUniqueIdProduct(User.getCounter()*3-1);
                return true;
            }
            else {
                System.out.println("用户注册失败！撤销用户游戏数据表");
                Long back =User.getCounter()-1L;
                User.setCounter(back);
                userGameDataDao.undoAddUserGameDataAutomatically();
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("用户注册失败！撤销用户游戏数据表");
            Long back =User.getCounter()-1L;
            User.setCounter(back);
            userGameDataDao.undoAddUserGameDataAutomatically();
            return false;
        }
    }

    public boolean loginUser(String phoneNumberOrEmail, String passwordNotJdbc ,String loginMethod) {

        if(loginMethod.equals("byPhoneNumber")) {

            String sql = "SELECT * FROM onlinechinesechess.user WHERE phoneNumber = ? AND password = ?";

            try {
                Connection conn = DriverManager.getConnection(jdbcUrl, userName, password);


                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, phoneNumberOrEmail);
                pstmt.setString(2, passwordNotJdbc);


                ResultSet rs = pstmt.executeQuery();

                if(rs.next())
                    return true;
                else{
                    System.out.println("没有找到账户");
                    return false;
                }


            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("一定要记得确认sql中的表名");
                return false;
            }

        }else if(loginMethod.equals("byEmail")){

            String sql = "SELECT * FROM onlinechinesechess.user WHERE email = ? AND password = ?";

            try {
                Connection conn = DriverManager.getConnection(jdbcUrl, userName, password);


                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, phoneNumberOrEmail);
                pstmt.setString(2, passwordNotJdbc);

                ResultSet rs = pstmt.executeQuery();
                if(rs.next())
                    return true;
                else{
                    System.out.println("没有找到账户");
                    return false;
                }
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }

        }else{


            return false;  //添加自定义异常
        }
    }
}