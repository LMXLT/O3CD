package ve.lm.onlinechinesechesscurriculumdesgino3cd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineChineseChessCurriculumDesginO3CdApplication {

    public static void main(String[] args) {
        SpringApplication.run(OnlineChineseChessCurriculumDesginO3CdApplication.class, args);
    }

}
