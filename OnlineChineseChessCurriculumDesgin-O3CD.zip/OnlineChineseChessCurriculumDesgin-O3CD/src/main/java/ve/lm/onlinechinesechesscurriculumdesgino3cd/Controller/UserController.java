package ve.lm.onlinechinesechesscurriculumdesgino3cd.Controller;

import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.Dto.LoginDto;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.User;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.ServiceImplement.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/O3CD/users")
public class UserController {

    @Autowired
    private UserServiceImpl userServiceImpl;

    @PostMapping("/register")
    public Boolean userRegister(@RequestBody User user) {
        return userServiceImpl.userRegister(user);
    }

    @PostMapping("/loginByPhoneNumber")
    public Boolean userLoginByPhoneNumber(@RequestBody LoginDto loginDto) {

        return userServiceImpl.userLoginByPhoneNumber(loginDto.getPhoneNumber(), loginDto.getPassword());

    }
    @PostMapping("/loginByEmail")
    public Boolean userLoginByEmail(@RequestBody LoginDto loginDto) {

        return userServiceImpl.userLoginByEmail(loginDto.getEmail(), loginDto.getPassword());

    }
}