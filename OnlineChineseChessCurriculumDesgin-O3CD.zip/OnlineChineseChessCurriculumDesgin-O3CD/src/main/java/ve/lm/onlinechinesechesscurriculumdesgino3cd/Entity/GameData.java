package ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity;

import java.io.Serializable;

public class GameData implements Serializable {

    private static final long serialVersionUID = 103L;
    private static Long counter = 37L;
    private Long uniqueId;
    private String gameType;
    private Long redPlay;
    private Long blackPlay;
    private int totalTime;
    private int totalSteps;
    private String status;
    private Long winner;


    public GameData(String gameType, Long redPlay, Long blackPlay, int totalTime, int totalSteps, String status, Long winner) {
        this.uniqueId = counter++;
        this.gameType = gameType;
        this.redPlay = redPlay;
        this.blackPlay = blackPlay;
        this.totalTime = totalTime;
        this.totalSteps = totalSteps;
        this.status = status;
        this.winner = winner;
    }


    public static Long getCounter() {
        return counter;
    }

    public static void setCounter(Long counter) {
        GameData.counter = counter;
    }

    public Long getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(Long uniqueId) {
        this.uniqueId = uniqueId;
    }

    public String getGameType() {
        return gameType;
    }

    public void setGameType(String gameType) {
        this.gameType = gameType;
    }

    public Long getRedPlay() {
        return redPlay;
    }

    public void setRedPlay(Long redPlay) {
        this.redPlay = redPlay;
    }

    public Long getBlackPlay() {
        return blackPlay;
    }

    public void setBlackPlay(Long blackPlay) {
        this.blackPlay = blackPlay;
    }

    public int getTotalTime() {
        return totalTime;
    }

    public void setTotalTime(int totalTime) {
        this.totalTime = totalTime;
    }

    public int getTotalSteps() {
        return totalSteps;
    }

    public void setTotalSteps(int totalSteps) {
        this.totalSteps = totalSteps;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getWinner() {
        return winner;
    }

    public void setWinner(Long winner) {
        this.winner = winner;
    }
}
