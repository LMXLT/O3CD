package ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class User implements Serializable {
    private static final long serialVersionUID = 101L;

    private static Long counter = 1L;

    private Long uniqueId;

    private String isManager;

    private String name;

    private String password;

    private String phoneNumber;

    private String email;

    private Long userGameDataId;




    @JsonCreator
    public User(@JsonProperty("isManager") String isManager,@JsonProperty("userName") String name, @JsonProperty("password") String password, @JsonProperty("phoneNumber") String phoneNumber,@JsonProperty(value = "email",required = false) String email,@JsonProperty ("userGameDataId") Long userGameDataId) {


        this.uniqueId = counter++;
        this.isManager = isManager;
        this.name = name;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.userGameDataId = null;
    }


    public User(String isManager, String name, String password, String phoneNumber, String email,Long gameDataId,String justWhat) {

        if(justWhat.equals("find")) {
            this.isManager = isManager;
            this.name = name;
            this.password = password;
            this.phoneNumber = phoneNumber;
            this.email = email;
            this.userGameDataId = userGameDataId;
        }
        else if(justWhat.equals("create")){
            this.uniqueId = counter++;
            this.isManager = isManager;
            this.name = name;
            this.password = password;
            this.phoneNumber = phoneNumber;
            this.email = email;
            this.userGameDataId = userGameDataId;
        }
    }


    public static Long getCounter(){
        return counter;
    }

    public static void setCounter(Long loadCounter) {
        counter = loadCounter;
    }

    public Long getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(Long uniqueId) {
        this.uniqueId = uniqueId;
    }

    public String getIsManager() {
        return isManager;
    }

    public void setIsManager(String isManager) {
        this.isManager = isManager;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Long getUserGameDataId() {
        return userGameDataId;
    }

    public void setUserGameDataId(Long gameDataId) {
        this.userGameDataId = gameDataId;
    }

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", password='" + password + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", email='" + email + '\'' +
                ", isManager=" + isManager +
                ", gameDataId=" + userGameDataId +
                '}';
    }

}

