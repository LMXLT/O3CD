package ve.lm.onlinechinesechesscurriculumdesgino3cd.Controller;


import com.sun.tools.javac.Main;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.MainGameOperation;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.Response.Start;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.Response.MainGameResponse;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.Response.ReadyResponse;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.SueForPeace;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.ServiceImplement.MainGameServiceImpl;

@RestController
@RequestMapping("/O3CD/mainGame")
public class MainGameController {

    @Autowired
    MainGameServiceImpl mainGameServiceImpl;

    @PostMapping("/moveChessman")
    public MainGameResponse<String> moveChessman(@RequestBody MainGameOperation operation)
    {
//        System.out.println("cX:"+operation.getCurX()+"\ncY:"+operation.getCurY()+"\ntX:"+operation.getTargetX()+"\ntY:"+operation.getTargetY());
        return mainGameServiceImpl.moveChessman(operation);
    }


    @GetMapping("/getMapData")
    public MainGameResponse<String> getMapData()
    {
        return mainGameServiceImpl.getMapData();
    }

    @PostMapping("/getReady")
    public ReadyResponse<String> getReady(@RequestBody ReadyResponse readyResponse){

        return mainGameServiceImpl.readyForGame(readyResponse);

    }

    @PostMapping("/start")
    public MainGameResponse<String> isStart(@RequestBody Start start){
        return mainGameServiceImpl.saveAndRestartGame(start.getStart());
    }

    @PostMapping("/sueForPeace")
        public MainGameResponse<String> sueForPeace(@RequestBody SueForPeace sueForPeace){
            return mainGameServiceImpl.isTie(sueForPeace.getOwner(),sueForPeace.getSFP());

        }


}
