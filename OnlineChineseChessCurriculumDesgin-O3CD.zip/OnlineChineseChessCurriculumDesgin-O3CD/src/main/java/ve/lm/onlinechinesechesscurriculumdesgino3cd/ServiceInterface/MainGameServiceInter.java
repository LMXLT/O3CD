package ve.lm.onlinechinesechesscurriculumdesgino3cd.ServiceInterface;

import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.MainGameBody;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.MainGameOperation;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.Response.MainGameResponse;

public interface MainGameServiceInter {

     MainGameResponse moveChessman(MainGameOperation operation);




}
