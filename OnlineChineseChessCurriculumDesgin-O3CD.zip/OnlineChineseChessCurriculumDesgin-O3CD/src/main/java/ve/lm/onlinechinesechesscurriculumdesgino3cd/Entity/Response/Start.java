package ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.Response;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Start<String> extends Response<String>{
    private Boolean start;



    @JsonCreator
    public Start(String description, @JsonProperty("start") Boolean start)
    {
        super(description);
        this.start = start;
    }

    public Boolean getStart() {
        return start;
    }

    public void setStart(Boolean start) {
        this.start = start;
    }
}
