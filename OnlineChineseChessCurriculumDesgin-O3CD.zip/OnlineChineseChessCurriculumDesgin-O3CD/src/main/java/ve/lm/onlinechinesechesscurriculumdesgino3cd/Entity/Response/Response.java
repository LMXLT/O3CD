package ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.Response;

public abstract class Response<T> {

    private T description;

    public Response(T description)
    {
        this.description = description;
    }

    public T getDescription() {
        return description;
    }

    public void setDescription(T description) {
        this.description = description;
    }
}
