package ve.lm.onlinechinesechesscurriculumdesgino3cd.ServiceImplement;

import java.io.*;

public class CounterServiceImpl {

    public static Long loadUserCounter(){

            try{
                ObjectInputStream ois = new ObjectInputStream(new FileInputStream("./ProgramFile/BackData/CurrentCounter/CurrentUserCounter.dat"));

                Long result =(Long)ois.readObject();

                ois.close();

                return result;

            }catch(IOException  | ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }

        public static boolean saveUserCounter(Long counter){

            try{
                ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("./ProgramFile/BackData/CurrentCounter/CurrentUserCounter.dat"));

                oos.writeObject(counter);

                oos.close();

                return true;

            }catch(IOException e){
                throw new RuntimeException(e);
            }

        }

        public static Long loadGameCounter(){

            try{
                ObjectInputStream ois = new ObjectInputStream(new FileInputStream("./ProgramFile/BackData/CurrentCounter/CurrentGameCounter.dat"));

                Long result =(Long)ois.readObject();

                ois.close();

                return result;

            }catch(IOException  | ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }

    public static boolean saveGameCounter(Long counter){

        try{
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("./ProgramFile/BackData/CurrentCounter/CurrentGameCounter.dat"));

            oos.writeObject(counter);

            oos.close();

            return true;

        }catch(IOException e){
            throw new RuntimeException(e);
        }

    }

}

