package ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity;

public class MainGameBody {


    private static final int MaxWidth = 9;

    private static final int MaxLength = 10;

    private String[][] chessBoard = new String[MaxLength][MaxWidth];
    public MainGameBody(){
        initializeChessBoard();
    };

    public  void initializeChessBoard(){

        for(int i=0;i<MaxLength;i++)
            for(int j=0;j<MaxWidth;j++)
                chessBoard[i][j] = "empty";

        chessBoard[0][0] = "redRook01";
        chessBoard[0][1] = "redKnight01";
        chessBoard[0][2] = "redElephant01";
        chessBoard[0][3] = "redMandarin01";
        chessBoard[0][4] = "redKing";
        chessBoard[0][5] = "redMandarin02";
        chessBoard[0][6] = "redElephant02";
        chessBoard[0][7] = "redKnight02";
        chessBoard[0][8] = "redRook02";
        chessBoard[2][1] = "redCannon01";
        chessBoard[2][7] = "redCannon02";
        chessBoard[3][0] = "redPawn01";
        chessBoard[3][2] = "redPawn02";
        chessBoard[3][4] = "redPawn03";
        chessBoard[3][6] = "redPawn04";
        chessBoard[3][8] = "redPawn05";

        chessBoard[9][0] = "blackRook01";
        chessBoard[9][1] = "blackKnight01";
        chessBoard[9][2] = "blackElephant01";
        chessBoard[9][3] = "blackMandarin01";
        chessBoard[9][4] = "blackGeneral";
        chessBoard[9][5] = "blackMandarin02";
        chessBoard[9][6] = "blackElephant02";
        chessBoard[9][7] = "blackKnight02";
        chessBoard[9][8] = "blackRook02";
        chessBoard[7][1] = "blackCannon01";
        chessBoard[7][7] = "blackCannon02";
        chessBoard[6][0] = "blackPawn01";
        chessBoard[6][2] = "blackPawn02";
        chessBoard[6][4] = "blackPawn03";
        chessBoard[6][6] = "blackPawn04";
        chessBoard[6][8] = "blackPawn05";

        System.out.println("棋盘初始化成功！");

    }


    public String getChessBoard(int x,int y){
        return chessBoard[y][x];
    }

    public void setChessBoard(int x,int y,String chess){
        chessBoard[y][x] = chess;
    }

    public String[][] getBody(){
        return chessBoard;
    }


}
