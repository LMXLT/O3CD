package ve.lm.onlinechinesechesscurriculumdesgino3cd.ServiceImplement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.GameData;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.MainGameBody;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.MainGameOperation;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.Response.MainGameResponse;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.Response.ReadyResponse;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.ServiceInterface.MainGameServiceInter;

@Service
public class MainGameServiceImpl implements MainGameServiceInter {

    @Autowired
    private GameDataServiceImpl gameDataServiceImpl;

    private MainGameBody mainGameBody= new MainGameBody()
            ;

    MainGameResponse<String> mainGameResponse = new MainGameResponse<String>("no","wait",null,"游戏未开始","noTie", mainGameBody.getBody());

    private static boolean flag = false;

    private int curSteps=0;
    private boolean isReadyRedPlayer =false;
    private boolean isReadyBlackPlayer=false;
    private boolean isRedTie=false;
    private boolean isBlackTie=false;

    public ReadyResponse<String> readyForGame(ReadyResponse readyResponse){

        if(readyResponse.getOwner().equals("redPlayer")&& readyResponse.getIsReady()) {

            isReadyRedPlayer = true;
        System.out.println("红方准备完毕！");
            return readyResponse;
        }else if(readyResponse.getOwner().equals("redPlayer")&& !readyResponse.getIsReady()) {

            System.out.println("红方要休息！");
            isReadyRedPlayer = false;
            return readyResponse;

        }


        if(readyResponse.getOwner().equals("blackPlayer")&& readyResponse.getIsReady()) {

            System.out.println("黑方准备完毕！");
            isReadyBlackPlayer = true;

        }else if(readyResponse.getOwner().equals("blackPlayer")&& !readyResponse.getIsReady()){

            System.out.println("黑方要休息！");
            isReadyBlackPlayer = false;

        }


        if(isReadyRedPlayer&&isReadyBlackPlayer) {

            mainGameResponse.setGameStatus("ing");
        }

        return readyResponse;

    }

    
    public MainGameResponse<String> moveChessman(MainGameOperation operation){


        if(mainGameResponse.getGameStatus().equals("wait")){
            mainGameResponse.setDescription("对局暂未开始！");
            return mainGameResponse;
        }


        String curChessman = mainGameBody.getChessBoard(operation.getCurX(),operation.getCurY());

        if(operation.getOwner().equals("redPlayer")){





            if(curChessman.equals("redRook01")||curChessman.equals("redRook02")
            || curChessman.equals("redKnight01")||curChessman.equals("redKnight02")||
            curChessman.equals("redElephant01")||curChessman.equals("redElephant02")||
            curChessman.equals("redMandarin01")||
            curChessman.equals("redMandarin02")||curChessman.equals("redKing")||
            curChessman.equals("redPawn01")||
            curChessman.equals("redPawn02")||
                    curChessman.equals("redPawn03")||
                    curChessman.equals("redPawn04")||
                    curChessman.equals("redPawn05")||
                    curChessman.equals("redCannon01")||
                    curChessman.equals("redCannon02")){

                if(!isLegalStep(operation)){

                    mainGameResponse.setIsLegal("no");
                    mainGameResponse.setDescription("走哪呢！？");
                    return mainGameResponse;

                }
                
               if(mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("empty")){

                   if(curChessman.contains("Cannon"))
                        if(flag){
                            mainGameResponse.setIsLegal("no");
                            mainGameResponse.setDescription("走哪呢！？");
                            return mainGameResponse;
                        }

                   
                   
                   mainGameBody.setChessBoard(operation.getTargetX(),operation.getTargetY(),curChessman);
                   
                   mainGameBody.setChessBoard(operation.getCurX(),operation.getCurY(),"empty");


                   mainGameResponse.setIsLegal("yes");
                   mainGameResponse.setDescription("转进成功！");
                   mainGameResponse.setChessBoard(mainGameBody.getBody());
                   curSteps++;
               }
               else if(mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("redRook01")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("redRook02")||
               mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("redKnight01")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("redKnight02")||
               mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("redElephant01")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("redElephant02")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("redMandarin01")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("redMandarin02")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("redKing")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("redCannon01")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("redCannon02")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("redPawn01")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("redPawn02")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("redPawn03")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("redPawn04")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("redPawn05")){
                   
                   
                   mainGameResponse.setIsLegal("no");
                   mainGameResponse.setDescription("自己人！");
                   
               }else{

                   if(curChessman.contains("Cannon"))
                       if(!flag){
                           mainGameResponse.setIsLegal("no");
                           mainGameResponse.setDescription("走哪呢！？");
                           return mainGameResponse;
                       }



                   
                   if(mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("blackGeneral")){


                       mainGameBody.setChessBoard(operation.getTargetX(),operation.getTargetY(),curChessman);
                       mainGameBody.setChessBoard(operation.getCurX(),operation.getCurY(),"empty");

                       mainGameResponse.setIsLegal("yes");
                       mainGameResponse.setGameStatus("wait");
                       mainGameResponse.setDescription("红方胜利！！");
                       mainGameResponse.setWinner("redPlayer");
                       mainGameResponse.setChessBoard(mainGameBody.getBody());
                       curSteps++;
                       return mainGameResponse;

                   }
                   
                   mainGameBody.setChessBoard(operation.getTargetX(),operation.getTargetY(),curChessman);
                   mainGameBody.setChessBoard(operation.getCurX(),operation.getCurY(),"empty");

                   mainGameResponse.setIsLegal("yes");
                   mainGameResponse.setDescription("进攻成功！");
                   mainGameResponse.setChessBoard(mainGameBody.getBody());
                   curSteps++;
                       
                                     
                   
               }



               if(isFace()){

                   mainGameBody.setChessBoard(operation.getTargetX(),operation.getTargetY(),curChessman);
                   mainGameBody.setChessBoard(operation.getCurX(),operation.getCurY(),"empty");

                   mainGameResponse.setIsLegal("yes");
                   mainGameResponse.setGameStatus("wait");
                   mainGameResponse.setDescription("黑方胜利！！");
                   mainGameResponse.setWinner("blackPlayer");
                   mainGameResponse.setChessBoard(mainGameBody.getBody());
                   curSteps++;
                   return mainGameResponse;
               }

               return mainGameResponse;


            }else{
                mainGameResponse.setIsLegal("no");
                mainGameResponse.setDescription("兵呢！？");
                return mainGameResponse;
            }
                


        }


        if(operation.getOwner().equals("blackPlayer")){



            if(curChessman.equals("blackRook01")||curChessman.equals("blackRook02")
                    || curChessman.equals("blackKnight01")||curChessman.equals("blackKnight02")||
                    curChessman.equals("blackElephant01")||curChessman.equals("blackElephant02")||
                    curChessman.equals("blackMandarin01")||
                    curChessman.equals("blackMandarin02")||curChessman.equals("blackGeneral")||
                    curChessman.equals("blackPawn01")||
                    curChessman.equals("blackPawn02")||
                    curChessman.equals("blackPawn03")||
                    curChessman.equals("blackPawn04")||
                    curChessman.equals("blackPawn05")||
                    curChessman.equals("blackCannon01")||
                    curChessman.equals("blackCannon02")){


                if(!isLegalStep(operation)){

                    mainGameResponse.setIsLegal("no");
                    mainGameResponse.setDescription("走哪呢！？");
                    return mainGameResponse;

                }


                if(mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("empty")){


                    if(curChessman.contains("Cannon"))
                        if(flag){
                            mainGameResponse.setIsLegal("no");
                            mainGameResponse.setDescription("走哪呢！？");
                            return mainGameResponse;
                        }
                    
                    mainGameBody.setChessBoard(operation.getTargetX(),operation.getTargetY(),curChessman);

                    mainGameBody.setChessBoard(operation.getCurX(),operation.getCurY(),"empty");

                    mainGameResponse.setIsLegal("yes");
                    mainGameResponse.setDescription("转进成功！");
                    mainGameResponse.setChessBoard(mainGameBody.getBody());
                    curSteps++;
                }
                else if(mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("blackRook01")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("blackRook02")||
                        mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("blackKnight01")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("blackKnight02")||
                        mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("blackElephant01")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("blackElephant02")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("blackMandarin01")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("blackMandarin02")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("blackKing")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("blackCannon01")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("blackCannon02")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("blackPawn01")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("blackPawn02")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("blackPawn03")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("blackPawn04")||mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("blackPawn05")){

                    mainGameResponse.setIsLegal("no");
                    mainGameResponse.setDescription("自己人！");


                }
                else{

                    if(curChessman.contains("Cannon"))
                        if(!flag){
                            mainGameResponse.setIsLegal("no");
                            mainGameResponse.setDescription("走哪呢！？");
                            return mainGameResponse;
                        }

                    if(mainGameBody.getChessBoard(operation.getTargetX(),operation.getTargetY()).equals("redKing")){

                        mainGameBody.setChessBoard(operation.getTargetX(),operation.getTargetY(),curChessman);
                        mainGameBody.setChessBoard(operation.getCurX(),operation.getCurY(),"empty");

                        mainGameResponse.setIsLegal("yes");
                        mainGameResponse.setGameStatus("wait");
                        mainGameResponse.setDescription("黑方胜利！！");
                        mainGameResponse.setWinner("blackPlayer");
                        mainGameResponse.setChessBoard(mainGameBody.getBody());
                        curSteps++;
                        return mainGameResponse;
                    }

                    mainGameBody.setChessBoard(operation.getTargetX(),operation.getTargetY(),curChessman);
                    mainGameBody.setChessBoard(operation.getCurX(),operation.getCurY(),"empty");

                    mainGameResponse.setIsLegal("yes");
                    mainGameResponse.setDescription("进攻成功！");
                    mainGameResponse.setChessBoard(mainGameBody.getBody());
                    curSteps++;


                }




                if(isFace()){

                    mainGameBody.setChessBoard(operation.getTargetX(),operation.getTargetY(),curChessman);
                    mainGameBody.setChessBoard(operation.getCurX(),operation.getCurY(),"empty");

                    mainGameResponse.setIsLegal("yes");
                    mainGameResponse.setGameStatus("wait");
                    mainGameResponse.setDescription("红方胜利！！");
                    mainGameResponse.setWinner("redPlayer");
                    mainGameResponse.setChessBoard(mainGameBody.getBody());
                    curSteps++;
                    return mainGameResponse;
                }

                return mainGameResponse;

            }else{
                mainGameResponse.setIsLegal("no");
                mainGameResponse.setDescription("兵呢！？");
                return mainGameResponse;

            }



        }else{
            mainGameResponse.setIsLegal("no");
            mainGameResponse.setDescription("你谁！？（未知棋手）");
            return mainGameResponse;
        }


    };

    public boolean isLegalStep(MainGameOperation operation){

        String chessman=mainGameBody.getChessBoard(operation.getCurX(),operation.getCurY());



        if(chessman.contains("Rook")){
            if(operation.getCurX()==operation.getTargetX()||operation.getCurY()==operation.getTargetY())
                return true;
        }
        else if(chessman.contains("Knight")) {



                if(operation.getCurX() - operation.getTargetX() == 1 && operation.getCurY() - operation.getTargetY() == 2 ||operation.getCurX() - operation.getTargetX() == -1 && operation.getCurY() - operation.getTargetY() == 2 )
                    if(mainGameBody.getChessBoard(operation.getCurX(),operation.getCurY()-1).equals("empty")){
                        System.out.println(mainGameBody.getChessBoard(operation.getCurX(),operation.getCurY()-1));

                       return true;
                    }


                if(operation.getCurX() - operation.getTargetX() == -1 && operation.getCurY() - operation.getTargetY() == -2||operation.getCurX() - operation.getTargetX() == 1 && operation.getCurY() - operation.getTargetY() == -2)
                    if(mainGameBody.getChessBoard(operation.getCurX(),operation.getCurY()+1).equals("empty"))
                        return true;

                if(operation.getCurX() - operation.getTargetX() == 2 && operation.getCurY() - operation.getTargetY() == 1 || operation.getCurX() - operation.getTargetX() == 2 && operation.getCurY() - operation.getTargetY() == -1)
                    if(mainGameBody.getChessBoard(operation.getCurX()-1,operation.getCurY()).equals("empty"))
                        return true;
                if(operation.getCurX() - operation.getTargetX() == -2 && operation.getCurY() - operation.getTargetY()==1||operation.getCurX()-operation.getTargetX()==-2&&operation.getCurY()-operation.getTargetY()==-1)
                    if(mainGameBody.getChessBoard(operation.getCurX()+1,operation.getCurY()).equals("empty"))
                        return true;


        }else if(chessman.contains("redElephant")){

            if(operation.getTargetY()<=4) {

                if (operation.getCurX() - operation.getTargetX() == 2 && operation.getCurY() - operation.getTargetY() == 2)
                    if (mainGameBody.getChessBoard(operation.getCurX() - 1, operation.getCurY() - 1).equals("empty"))
                        return true;
                if (operation.getCurX() - operation.getTargetX() == 2 && operation.getCurY() - operation.getTargetY() == -2)
                    if (mainGameBody.getChessBoard(operation.getCurX() - 1, operation.getCurY() + 1).equals("empty"))
                        return true;

                if (operation.getCurX() - operation.getTargetX() == -2 && operation.getCurY() - operation.getTargetY() == -2)
                    if (mainGameBody.getChessBoard(operation.getCurX() + 1, operation.getCurY() + 1).equals("empty"))
                        return true;
                if (operation.getCurX() - operation.getTargetX() == -2 && operation.getCurY() - operation.getTargetY() == 2)
                    if (mainGameBody.getChessBoard(operation.getCurX() + 1, operation.getCurY() - 1).equals("empty"))
                        return true;
            }

        }else if(chessman.contains("blackElephant")){

            if(operation.getTargetY()>=5) {

                if (operation.getCurX() - operation.getTargetX() == 2 && operation.getCurY() - operation.getTargetY() == 2)
                    if (mainGameBody.getChessBoard(operation.getCurX() - 1, operation.getCurY() - 1).equals("empty"))
                        return true;
                if (operation.getCurX() - operation.getTargetX() == 2 && operation.getCurY() - operation.getTargetY() == -2)
                    if (mainGameBody.getChessBoard(operation.getCurX() - 1, operation.getCurY() + 1).equals("empty"))
                        return true;

                if (operation.getCurX() - operation.getTargetX() == -2 && operation.getCurY() - operation.getTargetY() == -2)
                    if (mainGameBody.getChessBoard(operation.getCurX() + 1, operation.getCurY() + 1).equals("empty"))
                        return true;
                if (operation.getCurX() - operation.getTargetX() == -2 && operation.getCurY() - operation.getTargetY() == 2)
                    if (mainGameBody.getChessBoard(operation.getCurX() + 1, operation.getCurY() - 1).equals("empty"))
                        return true;
            }


        }
        else if(chessman.contains("Mandarin")){

                if(operation.getCurX()-operation.getTargetX()==1&&operation.getCurY()-operation.getTargetY()==1||operation.getCurX()-operation.getTargetX()==1&&operation.getCurY()-operation.getTargetY()==-1||operation.getCurX()-operation.getTargetX()==-1&&operation.getCurY()-operation.getTargetY()==1||operation.getCurX()-operation.getTargetX()==-1&&operation.getCurY()-operation.getTargetY()==-1)
                return true;

        }else if(chessman.equals("redKing")){


//            return true;
                if(operation.getTargetX()>5||operation.getTargetX()<3||operation.getTargetY()>2)
                    return false;

                if(operation.getCurX()-operation.getTargetX()==1&&operation.getCurY()==operation.getTargetY()||operation.getCurX()-operation.getTargetX()==-1&&operation.getCurY()==operation.getTargetY()||operation.getCurX()==operation.getTargetX()&&operation.getCurY()-operation.getTargetY()==1||operation.getCurX()==operation.getTargetX()&&operation.getCurY()-operation.getTargetY()==-1)
                    return true;



        }else if(chessman.equals("blackGeneral")){

            if(operation.getTargetX()>5||operation.getTargetX()<3||operation.getTargetY()<7)
                return false;

            if(operation.getCurX()-operation.getTargetX()==1&&operation.getCurY()==operation.getTargetY()||operation.getCurX()-operation.getTargetX()==-1&&operation.getCurY()==operation.getTargetY()||operation.getCurX()==operation.getTargetX()&&operation.getCurY()-operation.getTargetY()==1||operation.getCurX()==operation.getTargetX()&&operation.getCurY()-operation.getTargetY()==-1)
                return true;

        }
        else if(chessman.contains("redPawn")){
                if(operation.getCurY()<5) {
                    if (operation.getCurX() == operation.getTargetX() && operation.getCurY() - operation.getTargetY() == -1)
                        return true;
                }else{
                    if(operation.getCurX()==operation.getTargetX()&&operation.getCurY()-operation.getTargetY()==-1||operation.getCurX()-operation.getTargetX()==1&&operation.getCurY()==operation.getTargetY()||operation.getCurX()-operation.getTargetX()==-1&&operation.getCurY()== operation.getTargetY())
                        return true;
                }


        }
        else if(chessman.contains("blackPawn")){
            if(operation.getCurY()>4) {
                if (operation.getCurX() == operation.getTargetX() && operation.getCurY() - operation.getTargetY() == 1)
                    return true;
            }else{
                if(operation.getCurX()==operation.getTargetX()&&operation.getCurY()-operation.getTargetY()==1||operation.getCurX()-operation.getTargetX()==1&&operation.getCurY()==operation.getTargetY()||operation.getCurX()-operation.getTargetX()==-1&&operation.getCurY()== operation.getTargetY())
                    return true;
            }


        }
        else if(chessman.contains("Cannon")){

            flag = false;


            if(operation.getCurX()==operation.getTargetX()) {

                if(operation.getTargetY()>= operation.getCurY()) {


                    for (int i = 1; i < operation.getTargetY() - operation.getCurY(); i++)
                        if (!mainGameBody.getChessBoard(operation.getCurX(), operation.getCurY() + i).equals("empty") && !flag)
                            flag = true;
                        else if (!mainGameBody.getChessBoard(operation.getCurX(), operation.getCurY() + i).equals("empty") && flag)
                            return false;

                }else if(operation.getTargetY()< operation.getCurY()){

                    for (int i = 1; i < operation.getCurY() - operation.getTargetY(); i++)
                        if (!mainGameBody.getChessBoard(operation.getCurX(), operation.getCurY() - i).equals("empty") && !flag)
                            flag = true;
                        else if (!mainGameBody.getChessBoard(operation.getCurX(), operation.getCurY() - i).equals("empty") && flag)
                            return false;

                }

                return true;
            }else if(operation.getCurY()==operation.getTargetY()) {


                if(operation.getTargetX()>= operation.getCurX()) {

                    for (int i = 1; i < operation.getTargetX() - operation.getCurX(); i++)
                        if (!mainGameBody.getChessBoard(operation.getCurX() + i, operation.getCurY()).equals("empty") && !flag)
                            flag = true;
                        else if (!mainGameBody.getChessBoard(operation.getCurX() + i, operation.getCurY()).equals("empty") && flag)
                            return false;

                }else if(operation.getTargetX()< operation.getCurX()){

                    for (int i = 1; i < operation.getCurX() - operation.getTargetX(); i++)
                        if (!mainGameBody.getChessBoard(operation.getCurX() - i, operation.getCurY()).equals("empty") && !flag)
                            flag = true;
                        else if (!mainGameBody.getChessBoard(operation.getCurX() - i, operation.getCurY()).equals("empty") && flag)
                            return false;

                }

                return true;
            }

        }
        return false;

    }

    public boolean isFace(){

        int redX=4;
        int redY=0;
        int blackX=4;
        int blackY=9;

        for(int i=3;i<=5;i++)
            for(int j=0;j<=2;j++)
                if(mainGameBody.getChessBoard(i,j).equals("redKing")){
                    redX=i;
                    redY=j;
//                    System.out.println(i+" "+j);
                    break;

                }

        for(int i=3;i<=5;i++)
            for(int j=7;j<=9;j++)
                if(mainGameBody.getChessBoard(i,j).equals("blackGeneral")){
                    blackX=i;
                    blackY=j;
//                    System.out.println(i+" "+j);
                    break;
                }

        if(redX==blackX){

            for(int i=1;i<blackY-redY;i++)
                if(!mainGameBody.getChessBoard(redX,redY+i).equals("empty")) {

//                    System.out.println(redX + " " + (redY + i));
                    return false;
                }
            return true;
        }

        return false;



    }


    public MainGameResponse<String> saveAndRestartGame(boolean is){



        if(curSteps!=0) {

            GameData.setCounter(CounterServiceImpl.loadGameCounter());

            System.out.println("存了？"+GameData.getCounter());


            if (mainGameResponse.getGameEnd().equals("noTie")) {

                if (mainGameResponse.getDescription().equals("红方胜利！！"))
                    gameDataServiceImpl.addGameData(new GameData("mainGame", 1L, 2L, 0, curSteps, "noTie", 1L));
                else
                    gameDataServiceImpl.addGameData(new GameData("mainGame", 1L, 2L, 0, curSteps, "noTie", 2L));
            }
            else if (mainGameResponse.getGameEnd().equals("tie")) {

                gameDataServiceImpl.addGameData(new GameData("mainGame", 1L, 2L, 0, curSteps, "Tie", null));
            }d

            CounterServiceImpl.saveGameCounter(GameData.getCounter());
        }


        if(is) {

            mainGameBody.initializeChessBoard();
            curSteps = 0;
            mainGameResponse.setDescription("对局开始！");
            mainGameResponse.setIsLegal("yes");
            mainGameResponse.setGameStatus("ing");
            mainGameResponse.setWinner(null);
            mainGameResponse.setGameEnd("noTie");
            mainGameResponse.setChessBoard(mainGameBody.getBody());
            isReadyRedPlayer = false;
            isReadyBlackPlayer = false;
            isRedTie=false;
            isBlackTie=false;
            return mainGameResponse;
        }else{

            mainGameBody.initializeChessBoard();
            curSteps = 0;
            mainGameResponse.setDescription("开始休息！");
            mainGameResponse.setIsLegal("yes");
            mainGameResponse.setGameStatus("wait");
            mainGameResponse.setWinner(null);
            mainGameResponse.setGameEnd("noTie");
            mainGameResponse.setChessBoard(mainGameBody.getBody());
            isReadyRedPlayer = false;
            isReadyBlackPlayer = false;
            isRedTie=false;
            isBlackTie=false;
            return mainGameResponse;

        }

    }



    public MainGameResponse<String> getMapData(){

        return mainGameResponse;

    }

    public MainGameResponse<String> isTie(String owner,boolean is){

        if(is){
            if(owner.equals("redPlayer")){
                isRedTie=true;
            }else if(owner.equals("blackPlayer")){
                isBlackTie=true;
            }
            mainGameResponse.setIsLegal("yes");

        }else{
            if(owner.equals("redPlayer")){
                isRedTie=false;
            }else if(owner.equals("blackPlayer")){
                isBlackTie=false;
            }
            mainGameResponse.setIsLegal("no");
        }

        if(isRedTie&&isBlackTie){
            mainGameResponse.setGameEnd("tie");
            mainGameResponse.setDescription("平局");
            mainGameResponse.setGameStatus("wait");
        }

        return mainGameResponse;


    }
}
