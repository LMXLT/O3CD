package ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.Response;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class MainGameResponse<String> extends Response<String>{

    private String isLegal;
    private String gameStatus;
    private String winner;
    private String gameEnd;
    private String [][] chessBoard;



    @JsonCreator
    public MainGameResponse(@JsonProperty("isLegal") String  isLegal, @JsonProperty("gameStatus") String gameStatus, @JsonProperty("winner") String winner, @JsonProperty("description") String description, @JsonProperty("gameEnd") String gameEnd,@JsonProperty("chessBoard") String[][]  chessBoard) {
        super(description);
        this.isLegal = isLegal;
        this.gameStatus = gameStatus;
        this.winner = winner;
        this.gameEnd = gameEnd;
        this.chessBoard = chessBoard;
    }

    public String getIsLegal() {
        return isLegal;
    }

    public void setIsLegal(String isLegal) {
        this.isLegal = isLegal;
    }

    public String getGameStatus() {
        return gameStatus;
    }

    public void setGameStatus(String gameStatus) {
        this.gameStatus = gameStatus;
    }

    public String getWinner() {
        return winner;
    }

    public void setWinner(String winner) {
        this.winner = winner;
    }
    public String getGameEnd() {
        return gameEnd;
    }

    public void setGameEnd(String gameEnd) {
        this.gameEnd = gameEnd;
    }
    public String[][] getChessBoard() {
        return chessBoard;
    }

    public void setChessBoard(String[][] chessBoard) {
        this.chessBoard = chessBoard;
    }

}
