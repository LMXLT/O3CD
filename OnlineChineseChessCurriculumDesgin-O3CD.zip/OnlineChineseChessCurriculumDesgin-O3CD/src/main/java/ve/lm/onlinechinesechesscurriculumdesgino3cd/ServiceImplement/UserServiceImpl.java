package ve.lm.onlinechinesechesscurriculumdesgino3cd.ServiceImplement;

import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.GameData;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.User;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Dao.UserDao;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.UserGameData;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.ServiceInterface.UserServiceInter;

@Service
public class UserServiceImpl implements UserServiceInter {

    private static final String jdbcUrl="jdbc:mysql://localhost:3306/onlinechinesechess?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";

    private static final String userName = "root";

    private static final String password = "LMX!101110001lt";

    private final UserDao userDao = new UserDao(jdbcUrl, userName, password);


    static{

//          CounterServiceImpl.saveUserCounter(User.getCounter());
//        CounterServiceImpl.saveGameCounter(GameData.getCounter());
//  for the first building

        User.setCounter(CounterServiceImpl.loadUserCounter());  //加载用户计数器

        UserGameData.setUniqueIdProduct(CounterServiceImpl.loadUserCounter()*3-1);    //加载用户数据计数器

        GameData.setCounter(CounterServiceImpl.loadGameCounter());  //加载游戏计数器

        System.out.println("用户计数器： "+User.getCounter()+"\n用户游戏数据标识生成器："+UserGameData.getUniqueIdProduct()+"\n游戏计数器："+GameData.getCounter());

    }


    @Override
    public boolean userRegister(User user) {
        return userDao.registerUser(user);
//        System.out.println("这里");
//        System.out.println(user);
//        return true;
    }

    @Override
    public boolean userLoginByPhoneNumber(String phoneNumber, String password) {

//        System.out.println(phoneNumber+" "+password);
        return userDao.loginUser(phoneNumber, password,"byPhoneNumber");
    }
    @Override
    public boolean userLoginByEmail(String email, String password) {
        return userDao.loginUser(email, password,"byEmail");
    }
}