package ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class MainGameOperation {

    private boolean redPlayer=false;
    private boolean blackPlayer=false;
    private int curX;
    private int curY;
    private int targetX;
    private int targetY;


    @JsonCreator
    public MainGameOperation(@JsonProperty("owner") String owner,@JsonProperty("curX") int curX, @JsonProperty("curY") int curY,@JsonProperty("targetX") int targetX,@JsonProperty("targetY") int targetY){
        redPlayer = owner.equals("redPlayer");
        blackPlayer = owner.equals("blackPlayer");
        this.curX = curX;
        this.curY = curY;
        this.targetX = targetX;
        this.targetY = targetY;
    }


    public int getCurX() {
        return curX;
    }


    public void setCurX(int curX) {
        this.curX = curX;
    }

    public int getCurY() {
        return curY;
    }

    public void setCurY(int curY) {
        this.curY = curY;
    }

    public int getTargetX() {
        return targetX;
    }

    public void setTargetX(int targetX) {
        this.targetX = targetX;
    }

    public int getTargetY() {
        return targetY;
    }

    public void setTargetY(int targetY) {
        this.targetY = targetY;
    }

    public void setRedPlayer() {
        redPlayer=true;
        blackPlayer=false;
    }
    public void setBlackPlayer(){
        blackPlayer=true;
        redPlayer=false;
    }
    public String getOwner(){
        if(redPlayer)
            return "redPlayer";
        else
            return "blackPlayer";

    }
}
