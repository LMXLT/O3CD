package ve.lm.onlinechinesechesscurriculumdesgino3cd.ServiceInterface;

import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.User;



public interface UserServiceInter {



    public boolean userRegister(User user);

    public boolean userLoginByPhoneNumber(String phoneNumber, String password);

    public boolean userLoginByEmail(String email, String password);



}
