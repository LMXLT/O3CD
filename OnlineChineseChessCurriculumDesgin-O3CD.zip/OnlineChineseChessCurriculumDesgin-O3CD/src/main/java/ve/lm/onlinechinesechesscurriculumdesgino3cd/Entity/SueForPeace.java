package ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SueForPeace {

    private String owner;
    private Boolean isSFP;


    @JsonCreator
    public SueForPeace(@JsonProperty("owner") String owner,@JsonProperty("isSFP") Boolean isSFP) {
        this.owner = owner;
        this.isSFP = isSFP;

    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public Boolean getSFP() {
        return isSFP;
    }

    public void setSFP(Boolean SFP) {
        isSFP = SFP;
    }
}
