package ve.lm.onlinechinesechesscurriculumdesgino3cd.Dao;

import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.User;
import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.UserGameData;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UserGameDataDao {

    private String jdbcurl;
    private String userName;
    private String password;

    public UserGameDataDao(String jdbcurl, String userName, String password) {
        this.jdbcurl = jdbcurl;
        this.userName = userName;
        this.password = password;
    }

    public boolean addUserGameDataAutomatically(){

        String sql = "insert into userGameData (uniqueId) value(?)";

        try{

            Connection conn = DriverManager.getConnection(jdbcurl,userName,password);
            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setLong(1, UserGameData.getUniqueIdProduct());

            int result = ps.executeUpdate();

            if(result > 0){

                return true;
            }
            else{
                return false; //添加自定义异常
            }


        }catch(SQLException e){
            e.printStackTrace();
            return false;
        }

    }

    public boolean undoAddUserGameDataAutomatically(){

        String sql = "delete from userGameData where uniqueId = ?";

        try{

            Connection conn = DriverManager.getConnection(jdbcurl,userName,password);
            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setLong(1, UserGameData.getUniqueIdProduct());

            int result = ps.executeUpdate();

            return result > 0;


        }catch(SQLException e){
            e.printStackTrace();
            return false;
        }

    }

}
