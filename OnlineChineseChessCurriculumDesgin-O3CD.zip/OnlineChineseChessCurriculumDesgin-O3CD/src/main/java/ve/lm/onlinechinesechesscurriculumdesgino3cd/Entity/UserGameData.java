package ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity;

import java.io.Serializable;


public class UserGameData implements Serializable {
    private static final long serialVersionUID = 102L;

    private static Long uniqueIdProduct;

    private Long uniqueId;

    private Integer numberOfGame;

    private Integer numberOfGameWinning;

    private Integer winningRate;

    private Integer totalScore;

    private Integer fastestWinningTime;

    public UserGameData(Integer numberOfGame,Integer numberOfGameWinning,Integer winningRate,Integer totalScore,Integer fastestWinningTime) {
        this.uniqueId = uniqueIdProduct;
        this.numberOfGame = numberOfGame;
        this.numberOfGameWinning = numberOfGameWinning;
        this.winningRate = winningRate;
        this.totalScore = totalScore;
        this.fastestWinningTime = fastestWinningTime;
    }

    public static Long getUniqueIdProduct(){
        return uniqueIdProduct;
    }


    public static void setUniqueIdProduct(Long loadUniqueIdProduct){
        uniqueIdProduct =loadUniqueIdProduct ;
    }


    public Long getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(Long uniqueId) {
        this.uniqueId = uniqueId;
    }

    public Integer getNumberOfGame() {
        return numberOfGame;
    }

    public void setNumberOfGame(Integer numberOfGame) {
        this.numberOfGame = numberOfGame;
    }

    public Integer getNumberOfGameWinning() {
        return numberOfGameWinning;
    }

    public void setNumberOfGameWinning(Integer numberOfGameWinning) {
        this.numberOfGameWinning = numberOfGameWinning;
    }

    public Integer getWinningRate() {
        return winningRate;
    }

    public void setWinningRate(Integer winningRate) {
        this.winningRate = winningRate;
    }

    public Integer getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(Integer totalScore) {
        this.totalScore = totalScore;
    }

    public Integer getFastestWinningTime() {
        return fastestWinningTime;
    }

    public void setFastestWinningTime(Integer fastestWinningTime) {
        this.fastestWinningTime = fastestWinningTime;
    }

}

