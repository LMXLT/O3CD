package ve.lm.onlinechinesechesscurriculumdesgino3cd.Dao;

import ve.lm.onlinechinesechesscurriculumdesgino3cd.Entity.GameData;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class GameDataDao {

    private String jdbcUrl;
    private String userName;
    private String password;

    public GameDataDao(String jdbcurl, String userName, String password){
        this.jdbcUrl = jdbcurl;
        this.userName = userName;
        this.password = password;
    }

    public boolean addGameData(GameData gameData){

        String sql = "INSERT INTO gameData (gameType,redPlayer,blackPlayer,totalTime,totalSteps,status,winner) VALUES(?,?,?,?,?,?,?)";

        try{

            Connection conn = DriverManager.getConnection(jdbcUrl,userName,password);

            PreparedStatement pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, gameData.getGameType());
            pstmt.setLong(2, gameData.getRedPlay());
            pstmt.setLong(3, gameData.getBlackPlay());
            pstmt.setInt(4, gameData.getTotalTime());
            pstmt.setInt(5, gameData.getTotalSteps());
            pstmt.setString(6, gameData.getStatus());
            pstmt.setLong(7, gameData.getWinner());

            int affectedRows = pstmt.executeUpdate();

            return affectedRows > 0;

        }catch(SQLException e){
            e.printStackTrace();
            return false;
        }





    }


}
