function register() {
    var userName = document.getElementById('userName').value;
    var phoneNumber = document.getElementById('phoneNumber').value;
    var email = document.getElementById('email').value; // 获取邮箱输入框的值
    var password = document.getElementById('password').value;

    // 构建用户对象
    var user = {
        isManager: '否', // 假设默认不是管理员
        userName: userName,
        password: password,
        phoneNumber: phoneNumber,
        email: email, // 包含邮箱信息
        userGameDataId: null // 假设不需要游戏数据ID
    };

    // 发送注册请求到后端
    fetch('/O3CD/users/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(user)
    })
        .then(response => response.json())
        .then(data => {
            if (data) {
                alert('注册成功！');
            } else {
                alert('注册失败，出现错误！');
            }
        })
        .catch(error => console.error('Error:', error));
}