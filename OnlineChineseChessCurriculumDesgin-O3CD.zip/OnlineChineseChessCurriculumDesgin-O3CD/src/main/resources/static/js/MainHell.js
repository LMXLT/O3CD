function checkLoginStatus() {
    const isLoggedIn = sessionStorage.getItem('isLoggedIn'); // 使用 sessionStorage 来保存登录状态
    if (isLoggedIn === 'true') {
        document.getElementById('main-container').style.display = 'block';
        document.getElementById('login-container').style.display = 'none';
    } else {
        document.getElementById('main-container').style.display = 'none';
        document.getElementById('login-container').style.display = 'block';
    }
}

function goToLogin(){
    window.location.href = 'UserLogin.html';
}

function joinGame() {
    window.location.href = 'MainGameHell.html';
}

// 登录成功后设置登录状态
function setLoginStatus() {
    sessionStorage.setItem('isLoggedIn', 'true');
    checkLoginStatus();
}

// 登出时清除登录状态
function logout() {
    sessionStorage.removeItem('isLoggedIn');
    alert('您已退出登录');
    window.location.href = 'UserLogin.html'; // 登出后跳转到登录页面
}

// 页面加载时检查登录状态
window.onload = checkLoginStatus;