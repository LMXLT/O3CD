function login() {
    var loginMethod = document.getElementById('loginMethod').value;
    var phoneNumber = document.getElementById('phoneNumber').value;
    var password = document.getElementById('password').value;
    var email = document.getElementById('emailAddress').value;
    var passwordByEmail = document.getElementById('passwordByEmail').value;

    var url, data;
    if (loginMethod === 'phoneNumber') {
        url = '/O3CD/users/loginByPhoneNumber';
        data = {
            phoneNumber: phoneNumber,
            password: password
        };
    } else if (loginMethod === 'email') {
        url = '/O3CD/users/loginByEmail';
        data = {
            email: email,
            password: passwordByEmail
        };
    }

    // 发送登录请求到后端
    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
        .then(response => response.json())
        .then(data => {
            if (data) {
                alert('登录成功！');
                // 登录成功后保存状态并跳转到主界面
                sessionStorage.setItem('isLoggedIn', 'true');
                window.location.href = 'mainHell.html'; // 跳转到主界面
            } else {
                alert('登录失败，用户名或密码错误！');
            }
        })
        .catch(error => console.error('Error:', error));
}
