// 假设这是在您的 js/MainGame06.js 文件中
const pieceImages = {
    'redRook01': 'url(/FrontResource2/红车.gif)',
    'redRook02': 'url(/FrontResource2/红车.gif)',
    'redKnight01': 'url(/FrontResource2/红马.gif)',
    'redKnight02': 'url(/FrontResource2/红马.gif)',
    'redElephant01': 'url(/FrontResource2/红象.gif)',
    'redElephant02': 'url(/FrontResource2/红象.gif)',
    'redMandarin01': 'url(/FrontResource2/红士.gif)',
    'redMandarin02': 'url(/FrontResource2/红士.gif)',
    'redKing': 'url(/FrontResource2/红将.gif)',
    'redPawn01': 'url(/FrontResource2/红卒.gif)',
    'redPawn02': 'url(/FrontResource2/红卒.gif)',
    'redPawn03': 'url(/FrontResource2/红卒.gif)',
    'redPawn04': 'url(/FrontResource2/红卒.gif)',
    'redPawn05': 'url(/FrontResource2/红卒.gif)',
    'redCannon01': 'url(/FrontResource2/红炮.gif)',
    'redCannon02': 'url(/FrontResource2/红炮.gif)',

    'blackRook01': 'url(/FrontResource2/黑车.gif)',
    'blackRook02': 'url(/FrontResource2/黑车.gif)',
    'blackKnight01': 'url(/FrontResource2/黑马.gif)',
    'blackKnight02': 'url(/FrontResource2/黑马.gif)',
    'blackElephant01': 'url(/FrontResource2/黑象.gif)',
    'blackElephant02': 'url(/FrontResource2/黑象.gif)',
    'blackMandarin01': 'url(/FrontResource2/黑士.gif)',
    'blackMandarin02': 'url(/FrontResource2/黑士.gif)',
    'blackGeneral': 'url(/FrontResource2/黑将.gif)',
    'blackPawn01': 'url(/FrontResource2/黑卒.gif)',
    'blackPawn02': 'url(/FrontResource2/黑卒.gif)',
    'blackPawn03': 'url(/FrontResource2/黑卒.gif)',
    'blackPawn04': 'url(/FrontResource2/黑卒.gif)',
    'blackPawn05': 'url(/FrontResource2/黑卒.gif)',
    'blackCannon01': 'url(/FrontResource2/黑炮.gif)',
    'blackCannon02': 'url(/FrontResource2/黑炮.gif)',
};
let selectedX = null; // 记录选中棋子的X坐标
let selectedY = null; // 记录选中棋子的Y坐标
let currentOwner = "redPlayer";
let isStart = false;
let isRedTie=false;
let isBlackTie=false;

function initEventListeners() {
    console.log('事件监听器已初始化');
}

function fetchMapData() {
    fetch('/O3CD/mainGame/getMapData')
        .then(response => response.json())
        .then(data => {
            updateGameResponse(data); // 使用返回的数据更新游戏状态
        })
        .catch(error => {
            console.error('请求后端数据失败:', error);
        });
}


function updateGameResponse(response, isJustRebuild) {
    // 清空棋盘容器
    const chessboardContainer = document.getElementById('chessboard');
    chessboardContainer.innerHTML = '';

    // 更新棋子位置
    updatePieces(response.chessBoard);
    createChessButtons(chessboard);

    updatePlayerRoundDisplay();

    createHeText();
    createHanText();
    createLines();
    // 显示游戏状态
    if(!isJustRebuild)
    displayGameStatus(response.gameStatus, response.winner, response.gameEnd);

}



function updatePieces(chessBoard) {
    const chessboardContainer = document.getElementById('chessboard');
    const chessPieceSize = 70; // 每个棋子的大小为70px
    const startX = -35; // 棋盘的起始X坐标
    const startY = -35; // 棋盘的起始Y坐标

    for (let y = 0; y < chessBoard.length; y++) {
        for (let x = 0; x < chessBoard[y].length; x++) {
            const pieceName = chessBoard[y][x];
            if (pieceName !== "empty") {
                const chessPieceElement = document.createElement('div');
                chessPieceElement.className = 'chess-piece';
                const offsetX = startX + (x * chessPieceSize);
                const offsetY = startY + (y * chessPieceSize);
                chessPieceElement.style.left = offsetX + 'px';
                chessPieceElement.style.top = offsetY + 'px';
                chessPieceElement.style.width = chessPieceSize + 'px';
                chessPieceElement.style.height = chessPieceSize + 'px';
                chessPieceElement.style.position = 'absolute';
                chessPieceElement.style.backgroundSize = 'cover';
                chessPieceElement.setAttribute("data-x", x); // 设置棋子的坐标
                chessPieceElement.setAttribute("data-y", y);


                if (pieceImages[pieceName]) {
                    chessPieceElement.style.backgroundImage = pieceImages[pieceName];
                } else {
                    console.error(`Missing image for piece: ${pieceName}`);
                }
                chessboardContainer.appendChild(chessPieceElement);
            }
        }
    }
}

document.addEventListener("DOMContentLoaded", function () {
    const chessboard = document.getElementById("chessboard");
    const redReadyButton = document.getElementById('redReadyButton');
    const blackReadyButton = document.getElementById('blackReadyButton');

    // 检查准备按钮是否都隐藏
    function areReadyButtonsHidden() {
        return redReadyButton.style.display === 'none' && blackReadyButton.style.display === 'none';
    }

    // 创建棋子按钮，无论按钮是否隐藏，都需要创建棋子按钮
    createChessButtons(chessboard);

    // 从后端获取地图数据，无论按钮是否隐藏，都需要获取地图数据
    fetchMapData();

    updatePlayerRoundDisplay();

       createHeText();
       createHanText();
       createLines();


    // 检查准备按钮是否都隐藏，如果不是，则设置一个监听器来监测状态变化
    if (!areReadyButtonsHidden()) {
        const checkReadyButtonsInterval = setInterval(function() {
            if (areReadyButtonsHidden()) {
                clearInterval(checkReadyButtonsInterval); // 停止监测
                addChessboardClickListener(); // 添加点击事件监听器
            }
        }, 500); // 每500毫秒检查一次
    } else {
        addChessboardClickListener(); // 如果已经隐藏，直接添加点击事件监听器
    }

    function addChessboardClickListener() {
        // 为棋盘容器添加点击事件监听器，用于处理按钮和图片的点击
        chessboard.addEventListener('click', function(event) {
            let target = event.target;

            // 检查是否点击了棋子图片或按钮
            if (target.classList.contains('chess-piece') || target.classList.contains('chess-button')) {
                // 如果点击的是棋子图片，获取data-x和data-y属性
                if (target.classList.contains('chess-piece')) {
                    const pieceX = target.getAttribute("data-x");
                    const pieceY = target.getAttribute("data-y");
                    handleChessButtonClick(pieceX, pieceY);
                } else if (target.classList.contains('chess-button')) {
                    // 如果点击的是按钮，直接获取按钮的data-x和data-y属性
                    const buttonX = target.getAttribute("data-x");
                    const buttonY = target.getAttribute("data-y");
                    handleChessButtonClick(buttonX, buttonY);
                }
            }
        });
    }
});

function createHeText() {
    const heText = document.createElement('div');
    heText.className = 'chessboard-text';
    heText.id = 'he';
    heText.textContent = '楚河';
    document.getElementById('chessboard').appendChild(heText);
}

// 创建并添加“汉界”文本
function createHanText() {
    const hanText = document.createElement('div');
    hanText.className = 'chessboard-text';
    hanText.id = 'han';
    hanText.textContent = '汉界';
    document.getElementById('chessboard').appendChild(hanText);
}

// 创建并添加四条线
function createLines() {
    const lines = ['line01', 'line02', 'line03', 'line04','line05','line06'];
    lines.forEach(line => {
        const lineElement = document.createElement('div');
        lineElement.className = `chess-king-line ${line}`;
        document.getElementById('chessboard').appendChild(lineElement);
    });
}

// 创建并添加两条边线

function updatePlayerRoundDisplay() {
    const playerRoundDisplay = document.getElementById("playerRoundDisplay");
    if (currentOwner === "redPlayer") {
        playerRoundDisplay.textContent = "redPlayerRound";
    } else {
        playerRoundDisplay.textContent = "blackPlayerRound";
    }
}


function createChessButtons(chessboard) {
    const boardWidth = chessboard.offsetWidth;
    const boardHeight = chessboard.offsetHeight;
    const cellWidth = boardWidth / 8.35;
    const cellHeight = boardHeight / 9.24;

    for (let y = 0; y < 10; y++) {
        for (let x = 0; x < 9; x++) {
            const button = document.createElement("button");
            button.classList.add("chess-button");
            button.style.left = `${x * cellWidth}px`;
            button.style.top = `${y * cellHeight}px`;

            // 设置数据属性
            button.setAttribute("data-x", x);
            button.setAttribute("data-y", y);

            // 判断是否是最左边、最右边、最上面或最下面的按钮
            if (x === 0 || x === 8 || y === 0 || y === 9) {
                // 设置按钮透明度为0，使其看起来透明
                button.style.opacity = '0';
            }

            chessboard.appendChild(button);
        }
    }
}

function handleChessButtonClick(x, y) {
    if (selectedX === null && selectedY === null) {
        selectedX = x;
        selectedY = y;
        getCircleBySelect(x,y);
        console.log(`棋子选中坐标: (${selectedX}, ${selectedY})`);
    } else if (selectedX === x && selectedY === y) {
        selectedX = null;
        selectedY = null;
        removeSingleCircle();
        console.log(`棋子选择已取消`);
    } else {
        // 发送坐标请求，使用当前玩家作为 owner
        sendCoordinateRequest(selectedX, selectedY, x, y);
        removeSingleCircle();
        // 切换当前玩家
        selectedX = null;
        selectedY = null;
    }
}


function getCircleBySelect(x,y){
    // 获取容器元素
    var container = document.getElementById('chessboard');

    // 创建一个新的div元素作为圆圈
    var circle = document.createElement('div');

    // 添加CSS类，假设你的CSS类名为'circle'
    circle.classList.add('circle');

    // 设置圆圈的位置
    circle.style.position = 'absolute';
    circle.style.left = x*70-35 + 'px';
    circle.style.top = y*70-35 + 'px';

    // 将圆圈添加到指定的容器中
    container.appendChild(circle);
}

function removeSingleCircle() {
    // 获取容器元素
    var container = document.getElementById('chessboard');

    // 获取圆圈元素，假设只有一个圆圈，我们可以直接通过类名获取
    var circle = container.getElementsByClassName('circle')[0];

    // 如果找到了圆圈，就从容器中移除
    if (circle) {
        container.removeChild(circle);
    }
}

// 发送坐标请求
function sendCoordinateRequest(curX, curY, targetX, targetY) {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/O3CD/mainGame/moveChessman", true);
    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            try {
                const response = JSON.parse(xhr.responseText);
                console.log("操作已发送:", response);
                console.log("是否合法？"+response.isLegal);

                // 根据响应中的isLegal字段决定是否切换玩家
                if (response.isLegal === 'yes') {
                    // 操作成功，切换玩家
                    currentOwner = currentOwner === "redPlayer" ? "blackPlayer" : "redPlayer";
                    updatePlayerRoundDisplay(); // 更新显示当前玩家轮次的函数
                }

                updateGameResponse(response, false); // 更新棋盘状态
            } catch (error) {
                console.error("解析响应数据失败:", error);
            }
        }
    };

    const data = JSON.stringify({ owner: currentOwner, curX: curX, curY: curY, targetX: targetX, targetY: targetY });
    xhr.send(data);
}

// 发送准备状态请求
function sendReadyStatus(owner) {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/O3CD/mainGame/getReady", true);
    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            const response = JSON.parse(xhr.responseText);
            updateReadyButton(owner, response.isReady);
        }
    };

    // 获取按钮元素
    const redReadyButton = document.getElementById('redReadyButton');
    const blackReadyButton = document.getElementById('blackReadyButton');

    // 根据按钮颜色设置isReady值
    let isReady;
    if (owner === 'redPlayer') {
        isReady = !redReadyButton.classList.contains('ready');
    } else if (owner === 'blackPlayer') {
        isReady = !blackReadyButton.classList.contains('ready');
    }

    // 发送请求
    const data = JSON.stringify({ owner: owner, isReady: isReady });
    xhr.send(data);
}
// 更新准备按钮状态
function updateReadyButton(owner, isReady) {
    const redReadyButton = document.getElementById('redReadyButton');
    const blackReadyButton = document.getElementById('blackReadyButton');

    if (owner === 'redPlayer') {
        if (isReady) {
            redReadyButton.classList.add('ready');
            redReadyButton.textContent = '红方准备就绪';
        } else {
            redReadyButton.classList.remove('ready');
            redReadyButton.textContent = '红方准备';
        }
    } else if (owner === 'blackPlayer') {
        if (isReady) {
            blackReadyButton.classList.add('ready');
            blackReadyButton.textContent = '黑方准备就绪';
        } else {
            blackReadyButton.classList.remove('ready');
            blackReadyButton.textContent = '黑方准备';
        }
    }

    if (redReadyButton.classList.contains('ready') && blackReadyButton.classList.contains('ready')) {
        redReadyButton.style.display = 'none';
        blackReadyButton.style.display = 'none';
        isRedTie=false;
        isBlackTie=false;
        isStart=true;
        sendGameStartRequest(true); // 发送游戏开始请求
    }
}

function sendGameStartRequest(what) {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/O3CD/mainGame/start", true);
    xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");

    xhr.onreadystatechange = function () {
        // 确保请求已完成且响应码为200（成功）
        if (xhr.readyState === 4 && xhr.status === 200) {
            try {
                // 尝试解析响应数据
                const response = JSON.parse(xhr.responseText);
                updateGameResponse(response, false); // 更新棋盘状态
                displayGameStartMessage(); // 显示游戏开始的提示
                currentOwner = "redPlayer";
                updatePlayerRoundDisplay();
                isRedTie=false;
                isBlackTie=false;
                displayTieRequest(true,currentOwner,true);
            } catch (error) {
                // 如果解析响应数据失败，打印错误信息
                console.error("解析响应数据失败:", error);
            }
        }
    };

    const data = JSON.stringify({ start: what });
    xhr.send(data); // 发送请求
}

function displayGameStartMessage() {

    showMessage("对局开始！");

// 3秒后隐藏消息
    setTimeout(function() {
        hideMessage();
    }, 3000);
}


function updateReadyButtonsVisibility(gameStatus) {
    const redReadyButton = document.getElementById('redReadyButton');
    const blackReadyButton = document.getElementById('blackReadyButton');

    // 如果游戏状态是 "ing"（进行中），隐藏准备按钮
    if (gameStatus === "ing") {

        redReadyButton.textContent = '红方准备就绪';
        blackReadyButton.textContent = '黑方准备就绪';
        redReadyButton.classList.add('ready');
        blackReadyButton.classList.add('ready');
        redReadyButton.style.display = 'none';
        blackReadyButton.style.display = 'none';


    } else {
        // 如果游戏状态是 "wait"（等待），显示准备按钮
        redReadyButton.textContent = '红方准备';
        blackReadyButton.textContent = '黑方准备';
        redReadyButton.classList.remove('ready');
        blackReadyButton.classList.remove('ready');
        redReadyButton.style.display = 'inline-block';
        blackReadyButton.style.display = 'inline-block';

    }
}
// 在游戏状态更新时调用此函数
function displayGameStatus(gameStatus, winner, gameEnd) {
    const statusMessage = document.getElementById("status-message");
    if (winner) {

        showMessage(`${winner} 胜利!`);

// 3秒后隐藏消息
        setTimeout(function() {
            hideMessage();
        }, 3000);
        isStart=false;
        console.log("这里2"+isStart);

    } else if (gameEnd === "tie") {

        statusMessage.textContent = "游戏平局。";
        statusMessage.style.backgroundColor = "#ff0";
        statusMessage.style.opacity = 1;
        setTimeout(() => {
            statusMessage.style.opacity = 0;
        }, 3000);
        isStart=false;
        console.log("这里3"+isStart);


    } else if (gameStatus === "wait") {

        showMessage("对局还没开始呢！");

// 3秒后隐藏消息
        setTimeout(function() {
            hideMessage();
        }, 3000);

    } else if (gameStatus === "ing") {
        // statusMessage.textContent = "游戏正在进行中...";
        console.log("这里5"+isStart);
        //statusMessage.style.backgroundColor = "#9f9";
    }

    // 更新准备按钮的可见性
    updateReadyButtonsVisibility(gameStatus);
}

// 为返回按钮添加点击事件监听器
function goBackToMainGameHall() {

    if(isRedTie&&isBlackTie)
        isStart=false;

    console.log("这里"+isStart+"zg"+isRedTie+" "+isBlackTie);
    if(isStart) {
        // 显示确认弹窗
        var confirmExit = confirm('确认退出？退出默认认输。');

        // 检查用户是否点击了“确定”按钮
        if (confirmExit) {
            console.log('Returning to main game hall');
            sendGameStartRequest(false);
            window.location.href = 'MainGameHell.html'; // 替换为实际的游戏大厅路径
        } else {
            // 用户点击了“取消”或关闭弹窗，不执行任何操作
            console.log('Exit cancelled');
        }

    }else{
        window.location.href = 'MainGameHell.html';
    }

}
const statusMessage = document.getElementById("status-message");

function showMessage(message) {
    statusMessage.textContent = message;
    statusMessage.classList.remove('hide'); // 确保移除 hide 类
    statusMessage.classList.add('show'); // 显示消息并播放滑动进入动画
}

function hideMessage() {
    statusMessage.classList.remove('show'); // 移除 show 类
    statusMessage.classList.add('hide'); // 隐藏消息并播放滑动退出动画
}
function sfp(wait) {


    if(isStart) {

        if (currentOwner === "redPlayer") {

            console.log("求和撤销检测1"+" "+isRedTie+isBlackTie);

            if (isRedTie)
                what = false;
            else
                what = true;



        } else if (currentOwner === "blackPlayer") {

            if (isBlackTie)
                what = false;
            else
                what = true;

        }
        // 创建XMLHttpRequest对象
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "/O3CD/mainGame/sueForPeace", true);
        xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");

        // 定义请求完成的回调函数
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                try {
                    const response = JSON.parse(xhr.responseText);
                    if (response.isLegal === "yes") {

                        // 尝试解析响应数据

                        displayTieRequest(what, currentOwner,false);
                        updateGameResponse(response, false); // 更新棋盘状态
                        console.log("这里1"+isStart);


                    } else {

                        displayTieRequest(what, currentOwner,false);
                    }
                    isStart = true;
                } catch (error) {
                    // 如果解析响应数据失败，打印错误信息
                    console.error("解析响应数据失败:", error);
                }
            }
        }

        // 将请求体转换为JSON字符串
        const jsonData = JSON.stringify({owner: currentOwner, isSFP: what});
        // 发送请求
        xhr.send(jsonData);
    }else{

        const statusMessage = document.getElementById("status-message");

        showMessage("对局还没开始呢！");

// 3秒后隐藏消息
        setTimeout(function() {
            hideMessage();
        }, 3000);
    }
}

function displayTieRequest(isTie, owner, isStart2) {
    const offerDrawMessage = document.getElementById("offer-draw-message");



    if(!isStart2) {


        // 根据isTie布尔值和owner的值更新isRedTie和isBlackTie的状态
        if (isTie) {
            if (owner === "redPlayer") {
                isRedTie = true;
            } else if (owner === "blackPlayer") {
                isBlackTie = true;
            }
        } else {
            if (owner === "redPlayer") {
                //    console.log("求和提示检测1"+" "+isRedTie+isBlackTie)
                isRedTie = false;
            } else if (owner === "blackPlayer") {
                isBlackTie = false;
            }
        }
    }

    //console.log("求和提示检测2"+isTie+owner+" "+isRedTie+isBlackTie);

    // 根据isRedTie和isBlackTie的状态决定显示的消息
    let message = "";
    if (isRedTie) {
        message = "红方发出求和";
    } else if (isBlackTie) {
        message = "黑方发出求和";
    }

    // 如果红方和黑方都发出求和，且游戏已经开始，则显示平局信息
    if (isRedTie && isBlackTie && isStart) {
        message = "游戏平局。";
    } else if (!isRedTie && !isBlackTie) {
        // 如果没有一方请求求和，则隐藏消息
        message = "";
    }

    // 更新状态消息元素的内容和可见性
    if (message) {
        offerDrawMessage.style.opacity = 1; // 立即显示消息
        offerDrawMessage.textContent = message; // 设置消息内容
        offerDrawMessage.classList.add('visible'); // 添加.visible类以显示消息
    } else {
        offerDrawMessage.style.opacity = 0; // 如果消息为空，则隐藏消息
        offerDrawMessage.textContent = ''; // 清空消息内容
        offerDrawMessage.classList.remove('visible'); // 移除.visible类以隐藏消息
    }
}
