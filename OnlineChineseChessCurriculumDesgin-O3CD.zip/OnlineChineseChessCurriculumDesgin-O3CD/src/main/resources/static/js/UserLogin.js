function openTab(evt, tabName, loginMethod) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].classList.remove("active");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.classList.add("active");

    // 设置隐藏输入字段的值
    document.getElementById('loginMethod').value = loginMethod;
}

// 默认打开手机号登录
document.getElementById('phone').style.display = 'block';
document.getElementById('phoneTab').classList.add("active");

function login() {
    var loginMethod = document.getElementById('loginMethod').value;
    var phoneNumber = document.getElementById('phoneNumber').value;
    var password = document.getElementById('password').value;
    var email = document.getElementById('emailAddress').value;
    var passwordByEmail = document.getElementById('passwordByEmail').value;

    var url, data;
    if (loginMethod === 'phoneNumber') {
        url = '/O3CD/users/loginByPhoneNumber';
        data = {
            phoneNumber: phoneNumber,
            password: password
        };
    } else if (loginMethod === 'email') {
        url = '/O3CD/users/loginByEmail';
        data = {
            email: email,
            password: passwordByEmail
        };
    }

    // 发送登录请求到后端
    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
        .then(response => response.json())
        .then(data => {
            if (data) {
                alert('登录成功！');
                sessionStorage.setItem('isLoggedIn', 'true');
                window.location.href = 'mainHell.html';
            } else {
                alert('登录失败，用户名或密码错误！');
                if (loginMethod === 'phoneNumber') {
                    document.getElementById('password').value = '';
                } else if (loginMethod === 'email') {
                    document.getElementById('passwordByEmail').value = '';
                }
            }
        })
        .catch(error => console.error('Error:', error));
}