function goBackToMainHell() {
    window.location.href = "MainHell.html"; // 跳转回主界面
}

function goToGame06(){

    window.location.href ="MainGame06.html";

}